package com.exe.shojin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShojinApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShojinApplication.class, args);
	}

}
