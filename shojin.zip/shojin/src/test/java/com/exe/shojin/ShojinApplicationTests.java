package com.exe.shojin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShojinApplicationTests {

	@Test
	void contextLoads() {
	}

}
